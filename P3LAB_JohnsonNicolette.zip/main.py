i_year=int(input(""))

#check leap year

if((i_year % 4 == 0 and i_year % 100 != 0) or (i_year % 400 == 0)):

  print("{} - leap year".format(i_year))

else:

  print("{} - not a leap year".format(i_year))
 